# Daily Task Organizer

# Step 1: Create your checklist
tasks = [
    "Study Python",
    "Exercise",
    "Read a book",
    "Clean the room",
    "Write journal"
]

completed_tasks = []
incomplete_tasks = []

print("Daily Task Tracker")
print("------------------")

# Step 2: Check each task
for task in tasks:
    print(f"\nDid you complete this task? '{task}' (yes/no)")
    status = input().strip().lower()

    if status == "yes":
        completed_tasks.append(task)
    else:
        incomplete_tasks.append(task)

# Step 3: Show results
print("\n--- Summary ---")

print("\nCompleted Tasks:")
for task in completed_tasks:
    print(f"- {task}")

print("\nIncomplete Tasks:")
for task in incomplete_tasks:
    print(f"- {task}")